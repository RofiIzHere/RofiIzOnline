<?php
$host = "ftpupload.net";
$user = "if0_38569508";
$pass = "Rofi1223334444";
$db = "bani_patmo";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>